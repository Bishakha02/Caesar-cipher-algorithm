def caesar_cipher(text, shift, mode):
    result = ""
    for char in text:
        if char.isalpha():
            # Handle uppercase and lowercase separately
            base = ord('A') if char.isupper() else ord('a')
            if mode == 'encrypt':
                result += chr((ord(char) - base + shift) % 26 + base)
            elif mode == 'decrypt':
                result += chr((ord(char) - base - shift) % 26 + base)
        else:
            # Non-alphabetical characters remain unchanged
            result += char
    return result


def main():
    print("=== Caesar Cipher Program ===")
    message = input("Enter your message: ")
    shift = int(input("Enter shift value (integer): "))
    
    choice = input("Type 'encrypt' to encrypt or 'decrypt' to decrypt: ").lower()
    
    if choice == 'encrypt':
        encrypted_text = caesar_cipher(message, shift, 'encrypt')
        print(f"Encrypted Message: {encrypted_text}")
    elif choice == 'decrypt':
        decrypted_text = caesar_cipher(message, shift, 'decrypt')
        print(f"Decrypted Message: {decrypted_text}")
    else:
        print("Invalid choice. Please type 'encrypt' or 'decrypt'.")


if __name__ == "__main__":
    main()
